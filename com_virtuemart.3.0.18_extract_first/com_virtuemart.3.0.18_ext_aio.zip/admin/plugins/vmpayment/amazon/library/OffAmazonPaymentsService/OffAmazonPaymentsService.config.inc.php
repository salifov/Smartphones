<?php
$merchantId='';
$accessKey='';
$secretKey='';

/********************************************************************
 * Service endpoints for OffAmazonPaymentsService
 * 
 * Swap between live and sandbox using the urls defined below
 *******************************************************************/
$region='US';  // US, UK or DE  
$environment='SANDBOX'; // SANDBOX or LIVE
$applicationName='';
$applicationVersion='';
$clientId='';
$logFileLocation='';
$cnName='sns.amazonaws.com';
?>
